class Main {
  //CODED BY RYAN LEE AND WILLIAM LEE
  //Project details: https://docs.google.com/document/d/1fpfrymRpoF4CLl4iNepFudJsEhgaku23yfyDnFBMOvM/edit
  
  //============================ 1st Type Encryption =====================================
  public static String reverse (String msg) { 
    String result = "";
    for (int i = msg.length() - 1; i >= 0; i--) {
      result += msg.charAt(i);
    }
    return result;
  } 

  //============================ 2nd Type Encryption =====================================
  public static String msgAsciiEn (String msg) {
    String result = "";
    for (int i = 0; i < msg.length(); i ++) {
      result += (String.valueOf((int) msg.charAt(i))) + ",";
    }
    return result;
  }
  
  //============================ 3rd Type Encryption =====================================
  public static String numberBinEn (String msg) {
    String result = "";
    String remainder = msg;
    int dynamicPos = 0;
    while (dynamicPos < msg.length()) {
      result += Integer.toBinaryString(Integer.parseInt(remainder.substring(0,remainder.indexOf(",")))) + ",";
      dynamicPos += remainder.indexOf(",") + 1; //offset difference
      remainder = msg.substring(dynamicPos);
    }
    return result;
  }

  //============================ 4th Type Encryption =====================================
  public static String flipAddEn (String msg) {
    msg = msg.replace("0","5").replace("1","6");
    String result = "";
    String remainder = msg;
    int dynamicPos = 0;
    while (dynamicPos < msg.length()) {
      //random from 1 to 6
      result += remainder.substring(0,remainder.indexOf(",")) + "56" + String.valueOf((int)(Math.floor(Math.random() * 6)) + 1) + String.valueOf((int)(Math.floor(Math.random() * 6)) + 1) + "7";
      dynamicPos += remainder.indexOf(",") + 1; //offset difference
      remainder = msg.substring(dynamicPos);
    }
    return result;
  }

  //============================ 5th Type Encryption =====================================
  public static String subtractEn (String msg) { 
    String result = "";
    for (int i = 0; i < msg.length(); i ++) {
      if (i % 2 == 0) {
        result += Integer.parseInt(String.valueOf(msg.charAt(i))) - 1;
      } else {
        result += msg.charAt(i);
      }   
    }
    return result;
  }




  //============================ 1st Type Decryption =====================================
  
  //Reverse order, just use reverse again

  //============================ 2nd Type Decryption =====================================
  public static String msgAsciiDe (String msg) {
    String result = "";
    String remainder = msg;
    int dynamicPos = 0;
    while (dynamicPos < msg.length()) {
      result += (char) Integer.parseInt(remainder.substring(0,remainder.indexOf(",")));
      dynamicPos += remainder.indexOf(",") + 1; //offset difference
      remainder = msg.substring(dynamicPos);
    }
    return result;
  }
  
  //============================ 3rd Type Decryption =====================================
  public static String numberBinDe (String msg) {
    String result = "";
    String remainder = msg;
    int dynamicPos = 0;
    while (dynamicPos < msg.length()) {
      result += Integer.parseInt(remainder.substring(0,remainder.indexOf(",")), 2) + ",";
      dynamicPos += remainder.indexOf(",") + 1; //offset difference
      remainder = msg.substring(dynamicPos);
    }
    return result;
  }

  //============================ 4th Type Decryption =====================================
  public static String flipAddDe (String msg) {
    msg = msg.replace("5","0").replace("6","1");
    String result = "";
    String remainder = msg;
    int dynamicPos = 0;
    while (dynamicPos < msg.length()) {
      result += remainder.substring(0,remainder.indexOf("7") - 4) + ",";
      dynamicPos += remainder.indexOf("7") + 1; //offset difference
      remainder = msg.substring(dynamicPos);
      //Take position of every 7 and minus 4 to cut it out
    }
    return result;
  }

  //============================ 5th Type Decryption =====================================
  public static String subtractDe (String msg) { 
    String result = "";
    for (int i = 0; i < msg.length(); i ++) {
      if (i % 2 == 0) {
        result += String.valueOf(Integer.parseInt(msg.substring(i,i+1)) + 1);
      } else result += msg.charAt(i);
    }
    return result;
  }

  public static String encrypt(String msg) { //final product
      return subtractEn(flipAddEn(numberBinEn(msgAsciiEn(reverse(msg)))));
  }

  public static String decrypt(String msg) { //final product
      return reverse(msgAsciiDe(numberBinDe(flipAddDe(subtractDe(msg)))));
  }

  public static void main(String[] args) {
    //String ex1 = "abcd123";
    String file = "";
    System.out.println("If you want to encrypt a file, enter 1 or if you want to decrypt a file, enter 2");
    int EnOrDe = Input.readInt();
    if (EnOrDe == 1) {
      System.out.println("Enter file name for encryption: ");
      file = Input.readFile(Input.readString());
      Input.writeFile("YourFile.txt", encrypt(file));
    } else {
      System.out.println("Enter file name for decryption: ");
      file = Input.readFile(Input.readString());
      Input.writeFile("YourFile.txt", decrypt(file));
    }

    /*
    System.out.println("Original: " + ex1);
    String firstEn = reverse(ex1);
    System.out.println("First encryption: " + firstEn);
    String secondEn = msgAsciiEn(firstEn);
    System.out.println("Second encryption: " + secondEn); 
    String thirdEn = numberBinEn(secondEn);
    System.out.println("Third encryption: " + thirdEn); 
    String fourthEn = flipAddEn(thirdEn);
    System.out.println("Fourth encryption: " + fourthEn);
    String fifthEn = subtractEn(fourthEn);
    System.out.println("Fifth encryption: " + fifthEn); 

    String firstDe = subtractDe(fifthEn);
    System.out.println("First decryption: " + firstDe); 
    String secondDe = flipAddDe(firstDe);
    System.out.println("Second decryption: " + secondDe);
    String thirdDe = numberBinDe(secondDe);
    System.out.println("Third decryption: " + thirdDe); 
    String fourthDe = msgAsciiDe(thirdDe);
    System.out.println("Fourth decryption: " + fourthDe);
    String fifthDe = reverse(fourthDe);
    System.out.println("Fifth decryption: " + fifthDe);
    System.out.println("Final: " + decrypt(fifthEn)); 
  */
  }
}
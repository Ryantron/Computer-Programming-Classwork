$.ajaxSetup({async: false}); //So synchronous requests are made, although a synchronous XMLHttpRequest on the main thread is deprecated
      var data; //Globals to be recycled
      
      function getData() {
        var api_source = "https://data.cityofnewyork.us/resource/24t3-xqyv.json";
        data = $.getJSON(api_source).responseJSON;
        var queens = 0;
        var bronx = 0;
        var manhattan = 0;
        var brooklyn = 0;
        var staten_island = 0;

        for (var i = 0; i < data.length; i++) {
          if (data[i].boroname == "Queens") {
            queens++;
          } else if (data[i].boroname == "Bronx") {
            bronx++;
          } else if (data[i].boroname == "Manhattan") {
            manhattan++;
          }else if (data[i].boroname == "Brooklyn") {
            brooklyn++;
          }else if (data[i].borough == "Staten Island") {
            staten_island++;
          }
        }
      }

      function showData() {
        var output = document.getElementById("output");
        var build = "";
        var displaycard = document.getElementById("displaycard").innerHTML;
            //Queens choice
            for (var i = 0; i < data.length; i++) {
            if (document.getElementById("queens").checked == true) {
                if (data[i].boroname == "Queens") {
                  build += Mustache.render(displaycard, data[i]);
                }
              } else if (document.getElementById("bronx").checked == true) { //Bronx choice
                if (data[i].boroname == "Bronx") {
                  build += Mustache.render(displaycard, data[i]);
                }
              } else if (document.getElementById("manhattan").checked == true) { //Manhattan choice
                if (data[i].boroname == "Manhattan") {
                  build += Mustache.render(displaycard, data[i]);
                }
              } else if (document.getElementById("brooklyn").checked == true) {
                if (data[i].boroname == "Brooklyn") { //Brooklyn choice
                  build += Mustache.render(displaycard, data[i]);
                }
              } else if (document.getElementById("staten_island").checked == true) { //Staten Island choice
                if (data[i].boroname == "Staten Island") {
                  build += Mustache.render(displaycard, data[i]);
                }
            }
        }
      output.innerHTML = build; 
      }

    //HTML geolocation API
function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition, showError); //Returns a coordinate object
  } else { //Browser problem
    document.getElementById("userlatitude").value = "Geolocation is not supported by this browser.";
    document.getElementById("userlongitude").value = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  document.getElementById("userlatitude").value = position.coords.latitude;
  document.getElementById("userlongitude").value = position.coords.longitude;
}

function showError(error) {
  switch(error.code) { //Possible errors that will switch through cases with error type
    case error.PERMISSION_DENIED:
      document.getElementById("userlatitude").value = "User denied the request for Geolocation."
      document.getElementById("userlongitude").value = "User denied the request for Geolocation."
      break;
    case error.POSITION_UNAVAILABLE:
      document.getElementById("userlatitude").value = "Location information is unavailable."
      document.getElementById("userlongitude").value = "Location information is unavailable."
      break;
    case error.TIMEOUT:
      document.getElementById("userlatitude").value = "The request to get user location timed out."
      document.getElementById("userlongitude").value = "The request to get user location timed out."
      break;
    case error.UNKNOWN_ERROR:
      document.getElementById("userlatitude").value = "An unknown error occurred."
      document.getElementById("userlongitude").value = "An unknown error occurred."
      break;
  }
}

    function showHotspot() {
      var output = document.getElementById("output");
      var build = "";
      var displaycard = document.getElementById("displaycard").innerHTML;
      //Spherical law of cosines- distance of two coordinates. Reference: https://www.movable-type.co.uk/scripts/latlong.html
      

      var lat1 = parseFloat(document.getElementById("userlatitude").value)* Math.PI/180; //In Radians
      var lon1 = parseFloat(document.getElementById("userlongitude").value)* Math.PI/180;
      //lat2 and lon2 are part of the database side.

      var firstTime = true;
      var lowest = 0;
      var lowestIndex = 0;
      var latAllGood = false;
      var lonAllGood = false;
      //Below checks for invalid user inputs

      try { 
         if(document.getElementById("userlatitude").value == "") throw "Missing latitude"; //Basically check for null in a sense
         if(isNaN(lat1)) throw "Only numbers are permitted"; //NaN is also means empty and normal letters, but empty is ruled out.
        lat1 = Number(lat1); //Ensure number condition for decision
        if(lat1 < 0 || lat1 > 90*Math.PI/180) throw "Latitude does not exist"; //Latitude ranges from 0 to 90 degrees
        latAllGood = true; //Made the checkpoint- no errors
      }
      catch(err) {
        document.getElementById("userlatitude").value = err;
      }

      try {
      if(document.getElementById("userlongitude").value == "") throw "Missing longitude"; //Basically check for null in a sense
         if(isNaN(lon1)) throw "Only numbers are permitted"; //NaN is also means empty and normal letters, but empty is ruled out.
        lon1 = Number(lon1); //Ensure number condition for decision
        if(lon1 < -180*Math.PI/180 || lon1 > 180*Math.PI/180) throw "Longitude does not exist"; //Longitude ranges from -180 to 180 degrees
        lonAllGood = true; //Made the checkpoint- no errors
      }
      catch(err) {
        document.getElementById("userlongitude").value = err;
      }

      //If no errors for both:
        if (latAllGood === true && lonAllGood === true) {
          for (var i = 0; i < data.length; i++) {
        lat2 = parseFloat(data[i].latitude) * Math.PI/180;
        lon2 = parseFloat(data[i].longitude)* Math.PI/180;
        londiff = (lon2-lon1);
        radius = 6371e3;
        var distance = Math.acos( Math.sin(lat1)*Math.sin(lat2) + Math.cos(lat1)*Math.cos(lat2) * Math.cos(londiff)) * radius;
        if (firstTime === true) {
          lowestIndex = i; //To check if the first comparison is the closest distance from user.
          firstTime = false;
          lowest = distance;
          } else {
            if (distance < lowest) {
              lowest = distance;
              lowestIndex = i;
            }
          }
        }
        build += Mustache.render(displaycard, data[lowestIndex]);
        output.innerHTML = build;
        }
    }




      
        